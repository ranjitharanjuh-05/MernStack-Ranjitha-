import React from "react";
function Pass() {
    return <h1>Congratulations!</h1>;
}
function Fail() {
    return <h1>Better Luct Next Time!</h1>;
}
function ClassResult(props) {
    const isresult = props.isresult;
    if (isresult) {
        return <Pass />;
    }
    else{return <Fail />;}
}
export default ClassResult;
