import React from 'react'

/* function Car1({Color}) {
  return (
    <h2>My car is {Color}!</h2>
  );
} */

function Car1(props) {
    const {brand, model} = props;
  return (
    <h2>I love my {brand} {model}!</h2>
  );
}

  /* function Car1({Color, model, ...rest}) {
    return (
        <h2>My car details {Color} {model} {rest.brand}!</h2>
    );
  } */
 export default Car1;
