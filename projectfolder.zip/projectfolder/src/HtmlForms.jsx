import React from 'react'

function HtmlForms() {
  return (
    <form>
        <input type="email" id='user' /> <br />
        <input type="password" id='user' /> <br />
        <button>Submit</button>
    </form>
  )
}

export default HtmlForms