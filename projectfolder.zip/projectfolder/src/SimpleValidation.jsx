import {React, useState } from 'react'

function SimpleValidation() {
    const [email, setEmail] = useState("");
    const [error, setError] = useState("");
    const [number, setNumber] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        if (!email.includes("@")) {
            setError("Plese enter a valid email!");
        }else{
            setError("");
            alert(`Email Submitted: ${email}`);
        }
    }; 
   /* const handleSubmit1 = (e) => {
        e.preventDefault();
        if (number.length != 10) {
            setError("Plese enter a valid 10 digit number!");
        }else{
            setError("");
            alert(`Number Submitted: ${number}`);
        }
    }; */
  return (
    <form onSubmit={handleSubmit}>
        <input type="email" value={email} placeholder='Enter your Email' onChange={(e) => setEmail(e.target.value)} />
        <br />
        <button type="submit">Submit</button> <br />
        {/* <input type="number" value={number} placeholder='Enter your valid number' onChange={(e) => setEmail(e.target.value)} /> <br />
        <button type="submit">Submit</button> */}
        {/* {error && <p style={{color: "red"}}>{error}</p>} */}

    </form>
  );
  
}

export default SimpleValidation