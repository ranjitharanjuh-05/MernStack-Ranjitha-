import React from 'react'
import HtmlForms from './HtmlForms'
import ControlledForms from './ControlledForms'
import TwoWayBinding from './TwoWayBinding'
import SimpleValidation from './SimpleValidation'
function App() {
  return (
    <div>App</div>
    
  )
}

export default SimpleValidation