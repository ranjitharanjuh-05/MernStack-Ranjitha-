import React from 'react'
import UseEffect from './UseEffect'
import Counter from './Counter'
import Timer from './Timer'
import UsersList from './UsersList'
import Greeting from './Greeting'
import { Temperature } from './Greeting'
function App() {
  return (
    <div>
      App
      <UseEffect />
      <Counter />
      <Timer /> 
      <UsersList />
      <Greeting />
      <Temperature value={30}/>
    </div> 
  )
}
export default App