import React from "react"
import FirstComponent from './FirstComponent'
import Fruit from "./ClassComponent"
import Argument from "./Argument"
import Parent from "./PropsChildren"
function App() {
  return( 
      <div>
       App
       <FirstComponent/>
       <Fruit />
       <Argument name="Kavya" phno="88" />
       <Parent />
      </div>
  )
}
export default App