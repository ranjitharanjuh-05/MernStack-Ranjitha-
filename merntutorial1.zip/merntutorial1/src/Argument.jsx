import React from "react"; 
function Argument(props){ 
  return( 
    <div>Argument{props.phno} {props.name}</div>
  ) 

}
export default Argument